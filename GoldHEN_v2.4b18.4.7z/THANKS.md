Hi all! The new beta is finally out!
As many of you may already know, this version supports the new exploit and firmware 11.00, but support for 10.00 / 10.01 is also in development.
This new release supports both the previous WebKit exploits and the new pppwn, but for this it requires a custom stage2 that I wrote and released the [code](https://github.com/SiSTR0/PPPwn)
I'd like to take this opportunity to thank the people without whom we wouldn't have this (and other) release today:
- TheFlow for releasing his exploit (and not just this one) to everyone.
- flat_z for conceiving and publishing the hen for ps4 with a writeup.
- vortex for implementing the first versions of the hen.
- golden for creating projects that helped me understand many things.
- OSM for his cool Orbis Toolbox.
- Hippie68 for his work on the new FTP server.
- Al_Azif for providing various necessary resources.
- SocraticBliss for his RE scripts.
- Illusion for his game patches and more.
- bucanero for his work on the cheat manager.
- All the cheat developers who shared their trainers with everyone.

Thanks to the testers who had so much patience:
- Big_Wadger
- EchoStretch
- Opoisso893
- mbcrumb
- MODDED WARFARE
- vapour

Last but not least, my friends ctn and Kameleon for their continuous support, not only technical!

Thanks also to everyone who supported my project on kofi.